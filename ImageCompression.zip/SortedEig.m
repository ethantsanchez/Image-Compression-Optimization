function [V,D,Vsrtd,Dsrtd] = SortedEig(XVtilda,r)
    % Here, we sort and return the largest r eigenvalues and 
    %  eigenvectors of XVtilda*XVtilda' .
    [Vorig,Dorig] = eig(XVtilda*XVtilda');
    [d,ind] = sort(diag(Dorig),'descend');
    Dsrtd = Dorig(ind,ind);
    Vsrtd = Vorig(ind,ind);
    % V = zeros(n,n);
    % D = zeros(n,n);
    D = Dsrtd(1:r,1:r);
    V = Vsrtd(:,1:r);
end