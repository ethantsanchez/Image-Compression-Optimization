function [] = Errors(avgPatch,remastXhat,rdimEall,consArrays,file,r,rdimE)
    squaredError1str = (norm(avgPatch-remastXhat))^2;
    projX70tildaAll = rdimEall*((rdimEall'*rdimEall)^(-1))*rdimEall'*consArrays;
    remastXhatAll = projX70tildaAll + avgPatch;
    squaredErrorAll = (norm(avgPatch-remastXhatAll))^2; 
    percentage = (squaredError1str/squaredErrorAll) * 100;
    disp(newline + "For " + file + ", r=" + r + "," + newline + ...
        "the percentage of total squared error accounted for" + newline + ...
        "by using the first " + r + " eigenvector(s) is about ")
    format long
    disp(percentage)
    disp("percent.")
    whos rdimEall
    whos rdimE
end