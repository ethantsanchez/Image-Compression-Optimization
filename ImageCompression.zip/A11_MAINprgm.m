
clear, clc, clf, close all
load('PCA_Exercise_Images.mat')
who
size(Photo_Images) % 600 600 100 Image 1, Image 2, ... Image 100
% imagesc(Photo_Images(:,:,40))
% colormap(sqrt(gray(256)))
figure(1)
imagesc(Photo_Images(:,:,40))
colormap(sqrt(gray(256)))
size(VTEC_Images) % 180 360 365
figure(2)
imagesc(VTEC_Images(:,:,40))
colormap('default')

% size(Photo_Images,1)/20, size(Photo_Images,2)/20

n = 20; % For the code for parts (b),(c) to run, let n >= 5 AND n^2 > r,
% AND n divides size(..._Images,1), AND n divides size(..._Images,2).
D_Photo_Images = double(Photo_Images);

% Photo_Images introQ
image_num_P = 70; % 70 for the Assignment parameters
A11(n,Photo_Images,D_Photo_Images,image_num_P,"Photo _ Images");
% If wanting to test ONLY VTEC_Images, comment this block out (above 2 lines).

% % VTEC_Images introQ
image_num_V = 170; % 170 for the Assignment parameters
A11(n,VTEC_Images,VTEC_Images,image_num_V,"VTEC _ Images");
% % IF wanting to test ONLY Photo_Images, comment this block out (above 2 lines).

function [] = A11(n,Orig_Images,D_Images,image_num,file)
[allArrays,C,F] = TranscribeArray(n,D_Images);

% Qa
avgPatch = mean(allArrays,2);
newAvgPatch = reshape(avgPatch,[n n]);
figure
% imagesc(im2uint8(newAvgPatch))
imagesc(newAvgPatch)
if file == "Photo _ Images"
    colormap(sqrt(gray(256)))
end
title("Mean patch as a " + n + " by " + n + " image, " + file)

% Qb
Xtilda = allArrays-avgPatch;
[E,D,Eall,Dall] = SortedEig(Xtilda,10); % We only need to save Eall here.
eVecWantFirst = Eall(:,1:25);
figure('Position',[300 200 900 600])
for k = 1:size(eVecWantFirst,2)
    patchedEig = reshape(eVecWantFirst(:,k),[n n]);
    subplot(5,5,k);
    % plot(patchedEig)
    imagesc(im2uint8(patchedEig))
    if file == "Photo _ Images"
        colormap(gray)
    end
    title("E-vector " + k)
end
eVecWantLast = Eall(:,end-24:end);
figure('Position',[300 200 900 600])
for l = 1:size(eVecWantLast,2)
    patchedEig = reshape(eVecWantLast(:,l),[n n]);
    subplot(5,5,l);
    % plot(patchedEig)
    m = l+(n*n)-25;
    imagesc(im2uint8(patchedEig))
    if file == "Photo _ Images"
        colormap(gray)
    end
    title("E-vector " + m)
end

% Qc
%   Photo_Images: COLUMNS / PATCHES 62101-63000 ARE FOR IMAGE 70
des_stop = image_num*C*F;
des_array = des_stop-(C*F)+1:des_stop;
consArrays = allArrays(:,des_array); % X's
consXtilda = Xtilda(:,des_array); % Xtilda's
% consArrays = allArrays(:,62101:63000); % X's
% consXtilda = Xtilda(:,62101:63000);% Xtilda's

% Qc, r=10
r = 10;
[rdimE,rdimD,rdimEall,rdimDall] = SortedEig(consXtilda,r);
remastXhat = GlueItTogether(rdimE,consArrays,avgPatch,C,F,n,Orig_Images,image_num,r,file);
% Qd, r=10
% first r e-vectors sq error: Photo_ 6.8305e+08, VTEC_ 1.4880e+07
% total sq error: Photo_ 6.8347e+08, VTEC_ 1.4880e+07
Errors(avgPatch,remastXhat,rdimEall,consArrays,file,r,rdimE);

% Qc, r=1
r = 1;
[rdimE,rdimD,rdimEall,rdimDall] = SortedEig(consXtilda,r);
remastXhat = GlueItTogether(rdimE,consArrays,avgPatch,C,F,n,Orig_Images,image_num,r,file);
% Qd, r=1
% first r e-vectors sq error: Photo_ 6.8095e+08, VTEC_ 1.4877e+07
% total sq error: Photo_ 6.8347e+08, VTEC_ 1.4880e+07
Errors(avgPatch,remastXhat,rdimEall,consArrays,file,r,rdimE);

% Qc, r=80
r = 80;
[rdimE,rdimD,rdimEall,rdimDall] = SortedEig(consXtilda,r);
remastXhat = GlueItTogether(rdimE,consArrays,avgPatch,C,F,n,Orig_Images,image_num,r,file);
% Qd, r=80
% first r e-vectors sq error: Photo_ 6.8338e+08, VTEC_ 1.4880e+07
% total sq error: Photo_ 6.8347e+08, VTEC_ 1.4880e+07
Errors(avgPatch,remastXhat,rdimEall,consArrays,file,r,rdimE);

end



