function [remastXhat] = GlueItTogether(conE,consArrays,avgPatch,C,F,n,Orig_Images,image_num,r,file);
    projX70tilda1str = conE*((conE'*conE)^(-1))*conE'*consArrays;
    remastXhat = projX70tilda1str + avgPatch;
    
    gluedPatch = cell(C,F);
    for row = 1:C
        for col = 1:F
            gluedPatch{row,col} = reshape(remastXhat(:,(row-1)*F+col),[n n]);
        end
    end
    wholePatch = cell2mat(gluedPatch);
    figure('Position',[200 300 1175 500])
    subplot(1,2,1);
    imagesc(Orig_Images(:,:,image_num))
    if file == "Photo _ Images"
        colormap(gray)
    end
    title("Original image #" + image_num);
    subplot(1,2,2);
    imagesc(uint8(wholePatch))
    if file == "Photo _ Images"
        colormap(gray)
    end
    title("Re-Patched image #" + image_num + " with r = " + r);
end