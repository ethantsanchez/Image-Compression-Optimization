function [allArrays,C,F] = TranscribeArray(n,D_Images)
    % Photo_Images introQ
    for a = 1:size(D_Images,3)
        Array{a} = mat2cell(D_Images(:,:,a), ...
            (n*ones(size(D_Images,1)/n,1)'), ...
            (n*ones(size(D_Images,2)/n,1)'));
    end
    % Now, each image (indexed aa) is partitioned into 20x20 pixel patches.
    
    % size(Array), ans = 1 365
    % size(Array{1,3}), ans = 9 18. The 3 is from 1 to 365, FIRST 1 SAME
    % size(Array{1,3}{4,3}), ans = 20 20
    %  FIRST 1 SAME, 4 is from 1 to 9 (up-down), 3 from 1 to 18 (left-right)
    B = size(Array,2);
    C = size(Array{1,1},1);
    F = size(Array{1,1},2);
    allArrays = zeros(B*C*F,n*n)';
    i = 1;
    for b = 1:B % BB = 365 loaves
        % Array_V{1,bb} , 9x18 array of 20x20 doubles
        for c = 1:C % bb from 1 to 365, ROWS FROM UP TO DOWN, CC*FF = 252
            % Array_V{1,bb}{cc,:} , 1x18 array of 20x20 doubles
            for f = 1:F % ONE-'COLUMNS' FROM LEFT TO RIGHT
                % Array_V{1,bb}{cc,dd} , finally a 20x20 double.
                newArray = reshape(Array{1,b}{c,f},[n*n 1]);
                allArrays(:,i) = newArray;
                i = i+1;
            end
        end
    end
    % Now, each 20x20 'patch' is reshaped into a d=400 dim column vector.
    % allArraysV(:,ii) is one such 400 dimensional column vector.
    % allArraysV is a collection of 59,130 column vectors. PATCHES ARE RESHAPED.
    % column 1 corresponds to Array_V{1,1}{1,1}, 20x20 into 400x1; Image 1/365
    % column 2 corresponds to Array_V{1,1}{1,2}, 20x20 into 400x1; Image 1/365
    % ...
    % column 18 corresponds to Array_V{1,1}{1,18}, Image 1/365
    % column 19 corresponds to Array_V{1,1}{2,1}, Image 1/365
    % ...
    % column 36 corresponds to Array_V{1,1}{2,18}, Image 1/365
    % ...
    % column 162 corresponds to Array_V{1,1}{9,18}, Image 1/365
    %   COLUMNS / PATCHES 1-162 ARE FOR IMAGE 1
    
    
    % column 163 corresponds to Array_V{1,2}{1,1}, Image 2/365
    % ...
    % column 324 corresponds to Array_V{1,2}{9,18}, Image 2/365
    %   COLUMNS / PATCHES 163-324 ARE FOR IMAGE 2
    
    % ...
    % column 27379 corresponds to Array_V{1,170}{1,1}, Image 170/365
    % ...
    % column 27540 corresponds to Array_V{1,170}{9,18}, Image 170/365
    %   COLUMNS / PATCHES 27379-27540 ARE FOR IMAGE 170
    
    % ...
    % column 58969 corresponds to Array_V{1,365}{1,1}, Image 365/365
    % ...
    % column 59130 corresponds to Array_V{1,365}{9,18}, Image 365/365
    %   COLUMNS / PATCHES 58969-59130 ARE FOR IMAGE 365
    % EACH "PATCH" IS A SAMPLE.
    % 
    % 
    % allArraysV is X
end